/*
*
* Assignment 3
* Starter Files
*
* CS47SI
* Jan, 2017
*/

import Images from './Images'
import Metrics from './Metrics'
import Colors from './Colors'

export { Images, Metrics, Colors }
