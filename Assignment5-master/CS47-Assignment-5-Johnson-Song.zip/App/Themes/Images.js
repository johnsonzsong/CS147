/*
*
* Assignment 3
* Starter Files
*
* CS47SI
* Jan, 2017
*/

// leave off @2x/@3x
const images = {
  logo: require('../Images/nyt.png'),
}

export default images
