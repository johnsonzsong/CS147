/*
*
* Assignment 3
* Starter Files
*
* CS47SI
* Jan, 2017
*/

export default { //just some keys and endpoints for the NYT API.
  apiKey : '2ddfcf6f8b244f0daa7452ed176657a7',
  articleSearch : 'https://api.nytimes.com/svc/search/v2/articlesearch.json',
  topStories: 'https://api.nytimes.com/svc/topstories/v2/'
}
