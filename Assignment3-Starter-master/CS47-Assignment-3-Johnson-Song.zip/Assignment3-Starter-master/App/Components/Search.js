/*
*
* Assignment 3
* Starter Files
*
* CS47
* Oct, 2018
*/

import React, { Component } from 'react'
import PropTypes from 'prop-types' //consider using this!
import { StyleSheet, View, Button, TextInput, TouchableOpacity } from 'react-native'
import { FontAwesome, Feather } from '@expo/vector-icons';
import { Metrics, Colors } from '../Themes'


export default class Search extends Component {

  render () {
  }
}


const styles = StyleSheet.create({
});
